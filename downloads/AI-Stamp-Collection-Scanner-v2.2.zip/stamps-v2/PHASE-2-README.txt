PHASE 2 - AI-ASSISTED RESEARCH

Use AI-Research-Prompt-Phase2.txt with the existing vision-AI workflow. Run the same local processor as Phase 1. It now adds conservative research fields, independent confidence, image-quality checks, duplicate candidates and Collection Summary.

No catalogue number, rarity or value is asserted. Review every important finding manually. See PHASE-2-GUIDE.md.
