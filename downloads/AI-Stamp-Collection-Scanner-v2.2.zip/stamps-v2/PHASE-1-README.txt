OPTIONAL PHOTO TRACEABILITY

The standard prompt-to-Excel workflow remains available. For automatic crops and embedded thumbnails:

1. Install Python 3.10 or newer.
2. Run: python -m pip install -r requirements.txt
3. Produce detections.tsv with the Phase 1 prompt.
4. Put original images in a Photos folder.
5. Run:
   python tools/stamp_traceability.py --detections detections.tsv --photos Photos --template Stamp-Inventory-Template.xlsx --output Output

See 6-Phase-1-Traceability-Guide.pdf. Bounding boxes are AI estimates and require visual review.
